//	http://www.opengl-tutorial.org/beginners-tutorials/tutorial-3-matrices/
#include <array>
#include <fstream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>
#include <string>
#include <vector>

using namespace std;

int		window_width = 600;
int		window_height = 600;
char	window_title[] = "2D transformations";


std::vector<glm::vec3> myKocka;
std::vector<glm::vec3> mySokszog;

/* Vertex buffer objektum �s vertex array objektum az adatt�rol�shoz.*/
#define numVBOs 2
#define numVAOs 2
GLuint VBO[numVBOs];
GLuint VAO[numVAOs];

GLuint			renderingProgram;
unsigned int	transformLoc;

//glm::mat4 translateMatrix = glm::translate(glm::mat4(0.0f), glm::vec3(0.1f, 0.1f, 0.1f));
//glm::mat4 rotateMatrix = glm::rotate(glm::mat4(1.0f), 0.0f, glm::vec3(0.0f, 0.0f, 1.0f));
//glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.1f, 0.1f));
//glm::mat4 transformation(1.0f);

bool checkOpenGLError() {
	bool foundError = false;
	int glErr = glGetError();
	while (glErr != GL_NO_ERROR) {
		cout << "glError: " << glErr << endl;
		foundError = true;
		glErr = glGetError();
	}
	return foundError;
}

void printShaderLog(GLuint shader) {
	int len = 0;
	int chWrittn = 0;
	char* log;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
	if (len > 0) {
		log = (char*)malloc(len);
		glGetShaderInfoLog(shader, len, &chWrittn, log);
		cout << "Shader Info Log: " << log << endl;
		free(log);
	}
}

void printProgramLog(int prog) {
	int len = 0;
	int chWrittn = 0;
	char* log;
	glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
	if (len > 0) {
		log = (char*)malloc(len);
		glGetProgramInfoLog(prog, len, &chWrittn, log);
		cout << "Program Info Log: " << log << endl;
		free(log);
	}
}

string readShaderSource(const char* filePath) {
	string content;
	ifstream fileStream(filePath, ios::in);
	string line = "";

	while (!fileStream.eof()) {
		getline(fileStream, line);
		content.append(line + "\n");
	}
	fileStream.close();
	return content;
}

GLuint createShaderProgram() {

	GLint vertCompiled;
	GLint fragCompiled;
	GLint linked;

	string vertShaderStr = readShaderSource("vertexShader.glsl");
	string fragShaderStr = readShaderSource("fragmentShader.glsl");

	GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
	GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);

	const char* vertShaderSrc = vertShaderStr.c_str();
	const char* fragShaderSrc = fragShaderStr.c_str();

	glShaderSource(vShader, 1, &vertShaderSrc, NULL);
	glShaderSource(fShader, 1, &fragShaderSrc, NULL);

	glCompileShader(vShader);
	checkOpenGLError();
	glGetShaderiv(vShader, GL_COMPILE_STATUS, &vertCompiled);
	if (vertCompiled != 1) {
		cout << "vertex compilation failed" << endl;
		printShaderLog(vShader);
	}

	glCompileShader(fShader);
	checkOpenGLError();
	glGetShaderiv(vShader, GL_COMPILE_STATUS, &fragCompiled);
	if (fragCompiled != 1) {
		cout << "fragment compilation failed" << endl;
		printShaderLog(fShader);
	}

	// Shader program objektum l�trehoz�sa. Elt�roljuk az ID �rt�ket.
	GLuint vfProgram = glCreateProgram();
	glAttachShader(vfProgram, vShader);
	glAttachShader(vfProgram, fShader);

	glLinkProgram(vfProgram);
	checkOpenGLError();
	glGetProgramiv(vfProgram, GL_LINK_STATUS, &linked);
	if (linked != 1) {
		cout << "linking failed" << endl;
		printProgramLog(vfProgram);
	}

	glDeleteShader(vShader);
	glDeleteShader(fShader);

	return vfProgram;
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
}

void cursorPosCallback(GLFWwindow* window, double xPos, double yPos)
{
}

void mouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
}

void generateCirclePoints1(glm::vec2 start_point, GLfloat r, GLint num_segment) {
	GLfloat x, y;
	GLfloat alpha = 0.0f;
	GLfloat full_circle = 2.0f * M_PI;

	for (int i = 0; i <= num_segment - 1; i++) {
		x = start_point.x + r * cos(alpha);
		y = start_point.y + r * sin(alpha);

		myKocka.push_back(glm::vec3(x, y, 0.0f));

		if (i == 3) {
			myKocka.push_back(glm::vec3(1.0f, 0.0f, 0.0f));
		}
		else {
			myKocka.push_back(glm::vec3(0.0f, 1.0f, 0.0f));
		}
		alpha += full_circle / num_segment;
	}
}

void generateCirclePoints2(glm::vec2 start_point, GLfloat r, GLint num_segment) {
	GLfloat x, y;
	GLfloat alpha = 0.0f;
	GLfloat full_circle = 2.0f * M_PI;

	for (int i = 0; i <= num_segment - 1; i++) {
		x = start_point.x + r * cos(alpha);
		y = start_point.y + r * sin(alpha);

		mySokszog.push_back(glm::vec3(x, y, 0.0f));

		if (i == 3) {
			mySokszog.push_back(glm::vec3(1.0f, 0.0f, 0.0f));
		}
		else {
			mySokszog.push_back(glm::vec3(0.0f, 1.0f, 0.0f));
		}
		alpha += full_circle / num_segment;
	}
}

void init(GLFWwindow* window) {
	renderingProgram = createShaderProgram();

	generateCirclePoints1(glm::vec2(0.0f, 0.0f), GLfloat(1.0), 4);

	/* L�trehozzuk a sz�ks�ges Vertex buffer �s vertex array objektumot. */
	glGenVertexArrays(numVAOs, VAO);
	glGenBuffers(numVBOs, VBO);

	/* T�pus meghat�roz�sa: a GL_ARRAY_BUFFER neves�tett csatol�ponthoz kapcsoljuk a buffert (ide ker�lnek a vertex adatok). */
	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);

	/* M�soljuk az adatokat a pufferbe! Megadjuk az aktu�lisan csatolt puffert,  azt hogy h�ny b�jt adatot m�solunk,
	a m�soland� adatot, majd a feldolgoz�s m�dj�t is meghat�rozzuk: most az adat nem v�ltozik a felt�lt�s ut�n */
	glBufferData(GL_ARRAY_BUFFER, myKocka.size() * sizeof(glm::vec3), myKocka.data(), GL_STATIC_DRAW);


	/* Csatoljuk a vertex array objektumunkat a konfigur�l�shoz. */
	glBindVertexArray(VAO[0]);


	/* Ezen adatok szolg�lj�k a 0 index� vertex attrib�tumot (itt: poz�ci�).
	Els�k�nt megadjuk ezt az azonos�t�sz�mot.
	Ut�na az attrib�tum m�ret�t (vec3, l�ttuk a shaderben).
	Harmadik az adat t�pusa.
	Negyedik az adat normaliz�l�sa, ez maradhat FALSE jelen p�ld�ban.
	Az attrib�tum �rt�kek hogyan k�vetkeznek egym�s ut�n? Milyen l�p�sk�z ut�n tal�lom a k�vetkez� vertex adatait?
	V�g�l megadom azt, hogy honnan kezd�dnek az �rt�kek a pufferben. Most r�gt�n, a legelej�t�l veszem �ket.*/
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);

	/* Enged�lyezz�k az im�nt defini�lt 0 index� attrib�tumot. */
	glEnableVertexAttribArray(0);

	/* Sz�n attrib�tum */
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);





	generateCirclePoints2(glm::vec2(0.0f, 0.0f), GLfloat(1.0), 6);

	/* T�pus meghat�roz�sa: a GL_ARRAY_BUFFER neves�tett csatol�ponthoz kapcsoljuk a buffert (ide ker�lnek a vertex adatok). */
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);

	/* M�soljuk az adatokat a pufferbe! Megadjuk az aktu�lisan csatolt puffert,  azt hogy h�ny b�jt adatot m�solunk,
	a m�soland� adatot, majd a feldolgoz�s m�dj�t is meghat�rozzuk: most az adat nem v�ltozik a felt�lt�s ut�n */
	glBufferData(GL_ARRAY_BUFFER, mySokszog.size() * sizeof(glm::vec3), mySokszog.data(), GL_STATIC_DRAW);


	/* Csatoljuk a vertex array objektumunkat a konfigur�l�shoz. */
	glBindVertexArray(VAO[1]);


	/* Ezen adatok szolg�lj�k a 0 index� vertex attrib�tumot (itt: poz�ci�).
	Els�k�nt megadjuk ezt az azonos�t�sz�mot.
	Ut�na az attrib�tum m�ret�t (vec3, l�ttuk a shaderben).
	Harmadik az adat t�pusa.
	Negyedik az adat normaliz�l�sa, ez maradhat FALSE jelen p�ld�ban.
	Az attrib�tum �rt�kek hogyan k�vetkeznek egym�s ut�n? Milyen l�p�sk�z ut�n tal�lom a k�vetkez� vertex adatait?
	V�g�l megadom azt, hogy honnan kezd�dnek az �rt�kek a pufferben. Most r�gt�n, a legelej�t�l veszem �ket.*/
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);

	/* Enged�lyezz�k az im�nt defini�lt 0 index� attrib�tumot. */
	glEnableVertexAttribArray(0);

	/* Sz�n attrib�tum */
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);




	/* Lev�lasztjuk a vertex array objektumot �s a puufert is.*/
	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glClearColor(0.0, 0.0, 0.0, 1.0);
	// aktiv�ljuk a shader-program objektumunkat.
	glUseProgram(renderingProgram);

	transformLoc = glGetUniformLocation(renderingProgram, "transform");

}

/** A jelenet�nk ut�ni takar�t�s. */
void cleanUpScene()
{
	/** T�r�lj�k a vertex puffer �s vertex array objektumokat. */
	glDeleteVertexArrays(numVAOs, VAO);
	glDeleteBuffers(numVBOs, VBO);

	/** T�r�lj�k a shader programot. */
	glDeleteProgram(renderingProgram);
}

void display(GLFWwindow* window, double currentTime) {
	glClear(GL_COLOR_BUFFER_BIT); // fontos lehet minden egyes alkalommal t�r�lni!


	glm::mat4 transformation(1.0f);
	glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.21f, 0.21f, 0.21f));
	glm::mat4 rotateMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(45.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	//glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.0f));
	//transformation = translateMatrix * scaleMatrix * rotateMatrix;
	transformation = scaleMatrix * rotateMatrix;

	//glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));
	//glBindVertexArray(VAO[0]);
	//glDrawArrays(GL_LINE_LOOP, 0, 4);
	//glBindVertexArray(0);



	for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 6; j++) {
			glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(-1.0f + 0.30f*i, -1.0 + 0.30f *j, 0.0f));
			transformation = translateMatrix * scaleMatrix * rotateMatrix;

			glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));
			glBindVertexArray(VAO[0]);
			glDrawArrays(GL_LINE_LOOP, 0, 4);
			glBindVertexArray(0);
		}
	}

	glm::mat4 transformation2(1.0f);
	glm::mat4 rotateMatrix2 = glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 scaleMatrix2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.08f, 0.08f, 0.08f));
	transformation2 = scaleMatrix2 * rotateMatrix2;
	//glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation2));
	//glBindVertexArray(VAO[1]);
	//glDrawArrays(GL_LINE_LOOP, 0, 6);
	//glBindVertexArray(0);


	for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 6; j++) {
			glm::mat4 translateMatrix2 = glm::translate(glm::mat4(1.0f), glm::vec3(-1.0f + 0.30f * i, -1.0 + 0.30f * j, 0.0f));

			if (j % 2 == 0) {
				scaleMatrix2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.02f * i , 0.02f * i, 0.02f * i));
			}
			else {
				scaleMatrix2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.02f / i, 0.02f / i, 0.02f / i));
			}

			transformation2 = translateMatrix2 * scaleMatrix2 * rotateMatrix2;

			glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation2));
			glBindVertexArray(VAO[1]);
			glDrawArrays(GL_LINE_LOOP, 0, 6);
			glBindVertexArray(0);
		}
	}
}

//	for (int i = 0; i < 12; i++)
//	{
//		x = 0.0f + r * cos(alpha);
//		y = 0.0f + r * sin(alpha);
//		scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.1f, 0.1f));
//		glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f + x, 0.0f + y, 1.0f));
//		// glm::mat4 translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 2.0f, 2.0f));
//		glm::mat4 rotateMatrix = glm::rotate(glm::mat4(1.0f), glm::radians((30.0f * i)+90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
//		transformation = translateMatrix * rotateMatrix * scaleMatrix;
//
//		alpha += full_circle / 12;
//
//		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));
//		glBindVertexArray(VAO[0]);
//		glDrawArrays(GL_LINE_LOOP, 0, 4);
//		glBindVertexArray(0);

	/*
	for (int i = 1; i <= 12; i++)
	{   
		x = 0.0f + r * cos(alpha);
		y = 0.0f + r * sin(alpha);

		glm::mat4 transformation(1.0f);

		//translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3( 0.0f + x, 0.0f + y, 0.0f));
		//translateMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(0.01f + (i * 0.02f), 0.01 + (i * 0.02), 0.01 + (i * 0.02)));
		//rotateMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(15.0f * i), glm::vec3(0.0f, 0.0f, 1.0f));
		//scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f + (i*0.004f), 0.05f + (i * 0.004f), 0.05f + (i * 0.004f)));
		//transformation = translateMatrix * rotateMatrix * scaleMatrix;
		//transformation = scaleMatrix * rotateMatrix  * translateMatrix;

		glm::mat4 scaleMatrix = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.1f, 0.1f));
		glm::mat4 translateMatrix = glm::translate(glm::mat4(0.5f), glm::vec3(1.0f, 1.0f, 0.0f));
		transformation = scaleMatrix * translateMatrix;

		alpha += full_circle / i;

		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));
		glBindVertexArray(VAO[0]);
		glDrawArrays(GL_LINE_LOOP, 0, 4);
		glBindVertexArray(0);
	}*/
	


//	!!!BEWARE!!! This lines actually performs the scaling FIRST, and THEN the rotation, and THEN the translation.This is how matrix multiplication works.
	

//	You can try the opposite order also.
//	transformation = scaleMatrix * rotateMatrix * translateMatrix;

	/*Csatoljuk a vertex array objektumunkat. */
	

void framebufferSizeCallback(GLFWwindow* window, int width, int height)
{
	window_width = width;
	window_height = height;

	glViewport(0, 0, width, height);
}

int main(void) {

	/* Pr�b�ljuk meg inicializ�lni a GLFW-t! */
	if (!glfwInit()) { exit(EXIT_FAILURE); }

	/* A k�v�nt OpenGL verzi� (4.3) */
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	/* Pr�b�ljuk meg l�trehozni az ablakunkat. */
	GLFWwindow* window = glfwCreateWindow(window_width, window_height, window_title, NULL, NULL);

	/* V�lasszuk ki az ablakunk OpenGL kontextus�t, hogy haszn�lhassuk. */
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebufferSizeCallback);

	glfwSetKeyCallback(window, keyCallback);
	//glfwSetCursorPosCallback(window, cursorPosCallback);
	glfwSetMouseButtonCallback(window, mouseButtonCallback);

	/* Incializ�ljuk a GLEW-t, hogy el�rhet�v� v�ljanak az OpenGL f�ggv�nyek. */
	if (glewInit() != GLEW_OK) { exit(EXIT_FAILURE); }
	glfwSwapInterval(1);

	/* Az alkalmaz�shoz kapcsol�d� el�k�sz�t� l�p�sek, pl. hozd l�tre a shader objektumokat. */
	init(window);

	while (!glfwWindowShouldClose(window)) {
		/* a k�d, amellyel rajzolni tudunk a GLFWwindow ojektumunkba. */
		display(window, glfwGetTime());
		/* double buffered */
		glfwSwapBuffers(window);
		/* esem�nyek kezel�se az ablakunkkal kapcsolatban, pl. gombnyom�s */
		glfwPollEvents();
	}

	/* t�r�lj�k a GLFW ablakot. */
	glfwDestroyWindow(window);
	/* Le�ll�tjuk a GLFW-t */

	cleanUpScene();

	glfwTerminate();
	exit(EXIT_SUCCESS);
}