#version 430

uniform float offsetX;
uniform float offsetY;
layout (location = 0) in vec3 aPos;

void main(void)
{
	gl_Position = vec4(aPos.x + offsetX, aPos.y + offsetY, aPos.z, 1.0);
}